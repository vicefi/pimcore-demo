# API Documentation

Detailed [API documentation](https://phpgeo.marcusjaschen.de/api/) is available too.
