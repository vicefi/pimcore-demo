# Transformations and Processing

*phpgeo* provides tools for transforming and processing geometry instances.
It's possible to simplify a Polyline by removing unneeded points to save
storage space for example.
