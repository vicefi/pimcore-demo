# Calculations

The following chapters describe the possibilities to do geographical calculations with *phpgeo,* e.g. length and distance calculations, determining bearings, etc.
