<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class WriterNotOpenedException
 */
class WriterNotOpenedException extends WriterException
{
}
