<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class IteratorNotRewindableException
 */
class IteratorNotRewindableException extends ReaderException
{
}
