5.3
---

 * Add the component
 * Use `bcrypt` as default algorithm in `NativePasswordHasher`
