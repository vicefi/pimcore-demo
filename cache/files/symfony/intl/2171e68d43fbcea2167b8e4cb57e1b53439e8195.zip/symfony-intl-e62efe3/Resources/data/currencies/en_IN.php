<?php

return [
    'Names' => [
        'USD' => [
            0 => '$',
            1 => 'US Dollar',
        ],
        'VEF' => [
            0 => 'VEF',
            1 => 'Venezuelan Bolívar',
        ],
        'VES' => [
            0 => 'VES',
            1 => 'VES',
        ],
    ],
];
