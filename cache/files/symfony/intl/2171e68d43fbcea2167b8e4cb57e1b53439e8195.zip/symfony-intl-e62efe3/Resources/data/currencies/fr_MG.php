<?php

return [
    'Names' => [
        'MGA' => [
            0 => 'Ar',
            1 => 'ariary malgache',
        ],
    ],
];
