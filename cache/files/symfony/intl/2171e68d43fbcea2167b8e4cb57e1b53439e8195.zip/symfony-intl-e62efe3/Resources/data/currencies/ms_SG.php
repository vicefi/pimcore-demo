<?php

return [
    'Names' => [
        'SGD' => [
            0 => '$',
            1 => 'Dolar Singapura',
        ],
    ],
];
