<?php

return [
    'Names' => [
        'FJD' => [
            0 => '$',
            1 => 'Fijian Dollar',
        ],
    ],
];
