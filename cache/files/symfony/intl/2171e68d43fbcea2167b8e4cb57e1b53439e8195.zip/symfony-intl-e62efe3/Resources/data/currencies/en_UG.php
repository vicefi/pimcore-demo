<?php

return [
    'Names' => [
        'UGX' => [
            0 => 'USh',
            1 => 'Ugandan Shilling',
        ],
    ],
];
