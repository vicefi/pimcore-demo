<?php

return [
    'Names' => [
        'BMD' => [
            0 => '$',
            1 => 'Bermudian Dollar',
        ],
    ],
];
