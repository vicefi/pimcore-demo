<?php

return [
    'Names' => [
        'ANG' => [
            0 => 'NAf.',
            1 => 'Nederlands-Antilliaanse gulden',
        ],
    ],
];
