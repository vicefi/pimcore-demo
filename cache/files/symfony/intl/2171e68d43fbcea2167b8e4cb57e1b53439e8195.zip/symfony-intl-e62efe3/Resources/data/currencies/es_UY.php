<?php

return [
    'Names' => [
        'USD' => [
            0 => 'US$',
            1 => 'dólar estadounidense',
        ],
        'UYU' => [
            0 => '$',
            1 => 'peso uruguayo',
        ],
        'UYW' => [
            0 => 'UP',
            1 => 'unidad previsional uruguayo',
        ],
    ],
];
