<?php

return [
    'Names' => [
        'SLL' => [
            0 => 'Le',
            1 => 'Lewoon Seraa Liyon',
        ],
    ],
];
