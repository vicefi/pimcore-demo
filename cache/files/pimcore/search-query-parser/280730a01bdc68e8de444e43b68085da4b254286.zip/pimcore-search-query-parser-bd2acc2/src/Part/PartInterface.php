<?php

declare(strict_types=1);

namespace SearchQueryParser\Part;

interface PartInterface
{
}
