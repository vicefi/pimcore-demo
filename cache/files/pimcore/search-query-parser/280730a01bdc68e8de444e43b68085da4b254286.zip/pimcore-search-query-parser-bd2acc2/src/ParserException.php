<?php

declare(strict_types=1);

namespace SearchQueryParser;

class ParserException extends \RuntimeException
{
}
