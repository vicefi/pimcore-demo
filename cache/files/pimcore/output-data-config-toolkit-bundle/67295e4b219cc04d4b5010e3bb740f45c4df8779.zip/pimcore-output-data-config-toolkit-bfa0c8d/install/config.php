<?php

return [
    "channels" => [
        "channel1",
        "channel2"
    ]
];