<?php

namespace Laminas\Code\Generator\DocBlock\Tag;

use Laminas\Code\Generic\Prototype\PrototypeInterface;

interface TagInterface extends PrototypeInterface
{
}
