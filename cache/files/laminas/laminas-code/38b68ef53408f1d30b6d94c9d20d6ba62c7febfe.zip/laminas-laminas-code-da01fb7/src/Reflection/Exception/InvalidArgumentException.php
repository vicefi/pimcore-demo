<?php

namespace Laminas\Code\Reflection\Exception;

use Laminas\Code\Exception;

class InvalidArgumentException extends Exception\InvalidArgumentException implements
    ExceptionInterface
{
}
