<?php

namespace Phlexy;

class RestartException extends \RuntimeException {}