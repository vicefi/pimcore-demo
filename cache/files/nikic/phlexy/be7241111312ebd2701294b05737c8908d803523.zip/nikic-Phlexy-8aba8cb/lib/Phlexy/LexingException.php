<?php

namespace Phlexy;

class LexingException extends \RuntimeException {}