<?php

namespace Phlexy;

interface Lexer {
    public function lex($string);
}